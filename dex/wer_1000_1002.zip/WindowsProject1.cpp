#include <windows.h>
#include <thread>
#include <stdexcept>

// ��ť ID
#define ID_CRASH        101
#define ID_HANG_PROC    102
#define ID_HANG_THREAD  103
#define ID_HANG_QUIESCE 104
#define ID_HANG_IDLE    105
#define ID_HANG_TOPLVL  106
#define ID_HANG_CROSS_PROC 107


// ===== ��Ϊ���� =====

// Crash: Access Violation
void DoCrash() {
    int* p = nullptr;
    *p = 42; // c0000005
}

// Hang: Cross-process
void DoHangCrossProcess(HWND hWnd) {
    STARTUPINFO si = { sizeof(si) };
    PROCESS_INFORMATION pi;

    if (!CreateProcess(L"C:\\Windows\\system32\\notepad.exe", nullptr, nullptr, nullptr,
        FALSE, 0, nullptr, nullptr, &si, &pi)) {
        MessageBox(hWnd, L"Failed to start notepad.exe", L"Error", MB_OK);
        return;
    }

    // �� UI �߳���ȴ��ӽ��̽��� �� ��Զ����
    WaitForSingleObject(pi.hProcess, INFINITE);

    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
}

// Hang: Cross-thread (UI �ȴ���worker SendMessage)
void DoHangCrossThread(HWND hWnd) {
    HANDLE hEvent = CreateEvent(nullptr, TRUE, FALSE, nullptr);
    std::thread worker([&] {
        WaitForSingleObject(hEvent, INFINITE);
        SendMessage(hWnd, WM_USER + 2, 0, 0);
        });
    SetEvent(hEvent);
    WaitForSingleObject(worker.native_handle(), INFINITE); // ����
    worker.join();
}

// Hang: Quiesce (UI ����)
void DoHangQuiesce() {
    Sleep(100000); // 60 ��
}

// Hang: Idle (��Ϣѭ���� dispatch)
void DoHangIdle() {
    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        // ���ⲻ���� DispatchMessage
    }
}

// Hang: Top-level window idle
void DoHangTopLevelIdle(HINSTANCE hInst) {
    const wchar_t* cls = L"TopIdleClass";
    WNDCLASS wc = {};
    wc.lpfnWndProc = DefWindowProc;
    wc.hInstance = hInst;
    wc.lpszClassName = cls;
    RegisterClass(&wc);

    HWND hWnd = CreateWindow(cls, L"Top-level Idle Demo",
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 400, 300,
        nullptr, nullptr, hInst, nullptr);
    ShowWindow(hWnd, SW_SHOW);

    MSG msg;
    // ����ȡ��Ϣ�������ַ�
    while (GetMessage(&msg, nullptr, 0, 0)) {
        // ����ֻȡ��Ϣ�������� TranslateMessage/DispatchMessage
        // �������ڴ��ڣ�����ȫ����Ӧ
    }
}


// ===== ���ڹ��� =====
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case ID_CRASH:        DoCrash(); break;
        case ID_HANG_PROC:    DoHangCrossProcess(hWnd); break;
        case ID_HANG_THREAD:  DoHangCrossThread(hWnd); break;
        case ID_HANG_QUIESCE: DoHangQuiesce(); break;
        case ID_HANG_IDLE:    DoHangIdle(); break;
        case ID_HANG_TOPLVL:  DoHangTopLevelIdle((HINSTANCE)GetWindowLongPtr(hWnd, GWLP_HINSTANCE)); break;
        }
        break;
    case WM_USER + 1: Sleep(INFINITE); return 0; // Cross-processģ��
    case WM_USER + 2: Sleep(INFINITE); return 0; // Cross-threadģ��
    case WM_DESTROY:  PostQuitMessage(0); break;
    default: return DefWindowProc(hWnd, msg, wParam, lParam);
    }
    return 0;
}

// ===== ����� =====
int APIENTRY wWinMain(HINSTANCE hInst, HINSTANCE, LPWSTR, int nCmdShow) {
    const wchar_t CLASS_NAME[] = L"HangCrashDemo";

    WNDCLASS wc = {};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.lpszClassName = CLASS_NAME;
    RegisterClass(&wc);

    HWND hWnd = CreateWindow(CLASS_NAME, L"Hang/Crash Demo",
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 500, 500,
        nullptr, nullptr, hInst, nullptr);

    CreateWindow(L"BUTTON", L"Crash - OK", WS_TABSTOP | WS_VISIBLE | WS_CHILD,
        20, 20, 180, 30, hWnd, (HMENU)ID_CRASH, hInst, nullptr);

    CreateWindow(L"BUTTON", L"Hang Cross-process - OK", WS_TABSTOP | WS_VISIBLE | WS_CHILD,
        20, 60, 180, 30, hWnd, (HMENU)ID_HANG_PROC, hInst, nullptr);

    CreateWindow(L"BUTTON", L"Hang Cross-thread - OK", WS_TABSTOP | WS_VISIBLE | WS_CHILD,
        20, 100, 180, 30, hWnd, (HMENU)ID_HANG_THREAD, hInst, nullptr);

    CreateWindow(L"BUTTON", L"Hang Quiesce", WS_TABSTOP | WS_VISIBLE | WS_CHILD,
        20, 140, 180, 30, hWnd, (HMENU)ID_HANG_QUIESCE, hInst, nullptr);

    CreateWindow(L"BUTTON", L"Hang Idle", WS_TABSTOP | WS_VISIBLE | WS_CHILD,
        20, 180, 180, 30, hWnd, (HMENU)ID_HANG_IDLE, hInst, nullptr);

    CreateWindow(L"BUTTON", L"Hang Top-level Idle", WS_TABSTOP | WS_VISIBLE | WS_CHILD,
        20, 220, 180, 30, hWnd, (HMENU)ID_HANG_TOPLVL, hInst, nullptr);


    //CreateWindow(L"BUTTON", L"lock A - B", WS_TABSTOP | WS_VISIBLE | WS_CHILD,
    //    20, 300, 180, 30, hWnd, (HMENU)ID_LOCK_A_B, hInst, nullptr);

    //CreateWindow(L"BUTTON", L"lock B - A", WS_TABSTOP | WS_VISIBLE | WS_CHILD,
    //    20, 340, 180, 30, hWnd, (HMENU)ID_LOCK_B_A, hInst, nullptr);


    ShowWindow(hWnd, nCmdShow);

    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return 0;
}
